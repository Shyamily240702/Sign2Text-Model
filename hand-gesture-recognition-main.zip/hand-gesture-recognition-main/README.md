# hand-gesture-recognition

pip install -r requirements.txt

python hands_gesture_recog.py
